import { useState } from "react";
import { addDoc, collection, serverTimestamp } from "firebase/firestore";
import { db } from "../firebase";
import TodoModal from "../components/TodoModal";
import DayCell from "../components/DayCell";

const WEEKDAYS = ["S", "M", "T", "W", "T", "F", "S"];
const userId = "test-user";

// 👇 Helper สร้าง dateStr
function formatDate(year: number, month: number, day: number): string {
  return `${year}-${(month + 1).toString().padStart(2, "0")}-${day
    .toString()
    .padStart(2, "0")}`;
}

export default function Dashboard() {
  const today = new Date();
  const [modalDate, setModalDate] = useState<string | null>(null);

  const year = today.getFullYear();
  const month = today.getMonth();
  const totalDays = new Date(year, month + 1, 0).getDate();
  const startDay = new Date(year, month, 1).getDay();

  // 👉 สร้าง array วันที่
  const days: (number | null)[] = Array(startDay).fill(null).concat(
    Array.from({ length: totalDays }, (_, i) => i + 1)
  );
  while (days.length < 42) days.push(null);

  return (
    <div className="h-screen flex flex-col">
      <h1 className="text-xl font-bold text-center py-4">📅 ปฏิทิน To-do</h1>

      <div className="grid grid-cols-7 text-center font-semibold text-sm border-b">
        {WEEKDAYS.map((d, i) => (
          <div key={i} className="py-1">
            {d}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7 grid-rows-6 gap-px bg-gray-200 flex-1 text-[12px]">
        {days.map((day, idx) => {
          const dateStr = day ? formatDate(year, month, day) : "";

          return (
            <DayCell
              key={idx}
              day={day}
              dateStr={dateStr}
              userId={userId}
              onAddClick={() => setModalDate(dateStr)}
            />
          );
        })}
      </div>

      {/* ✅ Modal เพิ่ม To-do */}
      <TodoModal
        isOpen={!!modalDate}
        dateStr={modalDate || ""}
        onClose={() => setModalDate(null)}
        onSubmit={async (title) => {
          if (!modalDate) return;

          const ref = collection(db, "todos", userId, modalDate);
          await addDoc(ref, {
            title,
            completed: false,
            createdAt: serverTimestamp(),
          });

          setModalDate(null); // ปิด modal หลังเพิ่มสำเร็จ
        }}
      />
    </div>
  );
}
