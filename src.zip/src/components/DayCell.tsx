import { useTodosByDate, toggleComplete, removeTodo, updateTitle } from "../hooks/useTodosByDate";

export default function DayCell({ day, dateStr, userId, onAddClick }: {
  day: number | null;
  dateStr: string;
  userId: string;
  onAddClick: () => void;
}) {
  const todos = useTodosByDate(userId, dateStr); // ✅ ถูกต้อง

  if (!day) return <div className="bg-gray-100" />;

  return (
    <div className="bg-white flex flex-col p-1 text-xs">
      <div className="font-medium text-[10px]">{day}</div>

      {todos.map((todo) => (
        <div key={todo.id} className="flex items-center gap-1">
          <input
            type="checkbox"
            checked={todo.completed ?? false}
            onChange={(e) => toggleComplete(userId, dateStr, todo.id, e.target.checked)}
          />
          <input
            value={todo.title}
            onChange={(e) => updateTitle(userId, dateStr, todo.id, e.target.value)}
            className={`flex-1 bg-transparent outline-none text-[10px] ${
              todo.completed ? "line-through text-gray-400" : ""
            }`}
          />
          <button onClick={() => removeTodo(userId, dateStr, todo.id)} className="text-red-400">🗑</button>
        </div>
      ))}

      <button onClick={onAddClick} className="text-blue-500 text-[10px] underline mt-auto">
        + เพิ่ม To-do
      </button>
    </div>
  );
}