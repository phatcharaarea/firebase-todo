import { useState } from "react";

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (title: string) => void;
  dateStr: string;
}

export default function TodoModal({ isOpen, onClose, onSubmit, dateStr }: Props) {
  const [title, setTitle] = useState("");

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-sm">
        <h2 className="text-lg font-semibold mb-2">เพิ่ม To-do วันที่ {dateStr}</h2>
        <input
          className="border border-gray-300 px-3 py-2 w-full rounded mb-4"
          placeholder="ชื่อ To-do เช่น ไปประชุม"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <div className="flex justify-end gap-2">
          <button onClick={onClose} className="px-4 py-1 border rounded">ยกเลิก</button>
          <button
            onClick={() => {
              onSubmit(title);
              setTitle("");
              onClose();
            }}
            className="bg-blue-600 text-white px-4 py-1 rounded"
          >
            บันทึก
          </button>
        </div>
      </div>
    </div>
  );
}